%% Simulated Annealing-White Shark Optimizer (SA-WSO)
%The Simulated Annealing-White Shark Optimizer (SA-WSO) is a hybrid optimization algorithm
%that combines the principles of Simulated Annealing (SA) and
%the White Shark Optimizer (WSO). This hybrid approach aims to leverage the strengths of both algorithms to improve the efficiency and effectiveness of the optimization process.
%The SA-WSO algorithm typically follows these main steps:
%Initialization: Generate an initial population of candidate solutions randomly within the search space, as done in WSO [R1].
%Preying Behavior (WSO Phase): Sharks in the population select their prey based on their fitness values, using the hunting behavior of WSO. This phase promotes exploration and exploitation of the search space.
%Simulated Annealing Phase: Apply the SA algorithm to the best shark obtained from the WSO phase. This phase involves the following steps:
%a. Define the initial temperature and cooling schedule for SA.
%b. Iteratively modify the current solution (shark) by perturbing it and evaluating the neighboring solutions, similar to the SA algorithm.
%c. Determine whether to accept or reject the neighboring solution based on the acceptance probability, calculated using the SA acceptance criteria and the temperature.
%d. Decrease the temperature according to the cooling schedule until the termination criterion is met.
%Updating the Population: After completing the SA phase, update the population based on the best solution obtained from both the WSO and SA phases.
%Termination Criteria: The algorithm terminates when a specific stopping criterion is met, such as a maximum number of iterations or achieving a desired level of solution quality.
%The SA-WSO hybrid algorithm combines the global search capability of WSO with the local search and convergence properties of SA. 
%The WSO phase helps explore the search space efficiently, while the SA phase focuses on refining the solutions locally. 
%This combination aims to strike a balance between exploration and exploitation, potentially leading to improved convergence speed and solution quality.
% 
% R1-White Shark Optimizer: A novel bio-inspired meta-heuristic algorithm for global optimization problems
%   Knowledge-Based Systems DOI: https://doi.org/10.1016/j.knosys.2022.108457
%____________________________________________________________________________________
 
clear all ;
close all;
clc;
%% % Prepare the problem
dim = 2;
ub = 50 * ones(1, 2);
lb = -50 * ones(1, 2);
fobj=@ Objfun ;
%% % CSA parameters 
searchAgents = 30;
maxIter = 1000;
  
              [fitness_X,gbest_X,ccurve_X]=WSO(searchAgents,maxIter,lb,ub,dim,fobj);
              %Simulated Annealing-White Shark Optimizer (SA-WSO)
			  [fitness_y,gbest_y,ccurve_y]=SAWSO(searchAgents,maxIter,lb,ub,dim,fobj);
                     
              disp(['===> The optimal fitness value found by Standard Chameleon is ', num2str(fitness_X, 12)]);

% Draw the convergence behavior curve
figure;
set(gcf,'color','w');

plot(ccurve_X,'LineWidth',2,'Color','b'); 
grid on; hold on;
plot(ccurve_y,'LineWidth',2,'Color','r');
title('Convergence characteristic curve','interpreter','latex','FontName','Times','fontsize',10);
xlabel('Iteration','interpreter','latex','FontName','Times','fontsize',10);
ylabel('Best score obtained so far','interpreter','latex','FontName','Times','fontsize',10); 

axis tight; grid on; box on;

h1 = legend('WSO', 'SA-WSO', 'location', 'northeast');
set(h1,'interpreter','Latex','FontName','Times','FontSize',10);

ah = axes('position',get(gca,'position'),'visible','off');
