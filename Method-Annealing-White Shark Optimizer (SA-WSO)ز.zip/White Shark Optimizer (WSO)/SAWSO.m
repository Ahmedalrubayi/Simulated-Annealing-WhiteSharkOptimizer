% White Shark Optimizer (WSO) source codes version 1.0
function [fmin0,gbest,ccurve]=SAWSO(whiteSharks,itemax,lb,ub,dim,fobj)

%% Convergence curve
ccurve=zeros(1,itemax);
%% Start the WSO  Algorithm
%% Evaluate the fitness of the initial population
%Tm(1): temperature
%Tm(2): cooling rate
%Tm(3): % minimum temperature
%Tm=[10, 0.95,0.1];
Tm=[min(ub),0.95,0.01];
[fmin0,fitness,gbest,WSO_Positions,index] = simulatedAnnealing(fobj,whiteSharks,dim,ub,lb,Tm);
v=0.1*WSO_Positions; % initial velocity
wbest = WSO_Positions; % Best position initialization

%% Evaluate the fitness of the initial population

%% WSO Parameters
    fmax=0.75; %  Maximum frequency of the wavy motion
    fmin=0.07; %  Minimum frequency of the wavy motion   
    tau=4.11;         
    mu=2/abs(2-tau-sqrt(tau^2-4*tau));

    pmin=0.5;
    pmax=1.5;
    a0=6.250;  
    a1=100;
    a2=0.0005;
  %% Start the iterative process of WSO 
for ite=1:itemax

    mv=1/(a0+exp((itemax/2.0-ite)/a1)); 
    s_s=abs((1-exp(-a2*ite/itemax))) ;
 
    p1=pmax+(pmax-pmin)*exp(-(4*ite/itemax)^2);
    p2=pmin+(pmax-pmin)*exp(-(4*ite/itemax)^2);
    
 %% Update the speed of the white sharks in water  
     nu=floor((whiteSharks).*rand(1,whiteSharks))+1;

     for i=1:size(WSO_Positions,1)
           rmin=1; rmax=3.0;
          rr=rmin+rand()*(rmax-rmin);
          wr=abs(((2*rand()) - (1*rand()+rand()))/rr);       
          v(i,:)=  mu*v(i,:) +  wr *(wbest(nu(i),:)-WSO_Positions(i,:));
           %% or                

%          v(i,:)=  mu*(v(i,:)+ p1*(gbest-WSO_Positions(i,:))*rand+.... 
%                    + p2*(wbest(nu(i),:)-WSO_Positions(i,:))*rand);          
     end
 
 %% Update the white shark position
     for i=1:size(WSO_Positions,1)
       
        f =fmin+(fmax-fmin)/(fmax+fmin);
         
        a=sign(WSO_Positions(i,:)-ub)>0;
        b=sign(WSO_Positions(i,:)-lb)<0;
         
        wo=xor(a,b);

        % locate the prey based on its sensing (sound, waves)
            if rand<mv
                WSO_Positions(i,:)=  WSO_Positions(i,:).*(~wo) + (ub.*a+lb.*b); % random allocation  
            else   
                WSO_Positions(i,:) = WSO_Positions(i,:)+ v(i,:)/f;  % based on the wavy motion
            end
    end 
    
    %% Update the position of white sharks consides_sng fishing school 
for i=1:size(WSO_Positions,1)
        for j=1:size(WSO_Positions,2)
            if rand<s_s      
                
             Dist=abs(rand*(gbest(j)-1*WSO_Positions(i,j)));
             
                if(i==1)
                    WSO_Positions(i,j)=gbest(j)+rand*Dist*sign(rand-0.5);
                else    
                    WSO_Pos(i,j)= gbest(j)+rand*Dist*sign(rand-0.5);
                    WSO_Positions(i,j)=(WSO_Pos(i,j)+WSO_Positions(i-1,j))/2*rand;
                end   
            end
         
        end       
end
%     

%% Update global, best and new positions
 
    for i=1:whiteSharks 
        % Handling boundary violations
           if WSO_Positions(i,:)>=lb & WSO_Positions(i,:)<=ub%         
            % Find the fitness
              fit(i)=fobj(WSO_Positions(i,:));    
              
             % Evaluate the fitness
            if fit(i)<fitness(i)
                 wbest(i,:) = WSO_Positions(i,:); % Update the best positions
                 fitness(i)=fit(i);   % Update the fitness
            end
            
            %% Finding out the best positions
            if (fitness(i)<fmin0)
               fmin0=fitness(i);
               gbest = wbest(index,:); % Update the global best positions
            end 
            
        end
    end

 %% Obtain the results
  outmsg = ['Iteration# ', num2str(ite) , '  Fitness= ' , num2str(fmin0)];
  disp(outmsg);

 ccurve(ite)=fmin0; % Best found value until iteration ite

 if ite>2
        line([ite-1 ite], [ccurve(ite-1) ccurve(ite)],'Color','r'); 
        title({'Convergence characteristic curve'},'interpreter','latex','FontName','Times','fontsize',12);
        xlabel('Iteration');
        ylabel('Best score obtained so far');
        drawnow 
 end 
  
end 


end




function [fmin0,fitness,gbest,wbest,index] = simulatedAnnealing(Fun,N,dim,ub,lb,Tm)
% Simulated annealing algorithm
Positions=initialization(N,dim,ub,lb);
temperature = Tm(1);      % initial temperature
iter = N;           %Number of iterations of the inner Monte Carlo loop
enegy=0;
value =Disturb(dim,lb,ub);
count = 1;
enegy(count)=Fun(value);

while temperature > Tm(3)      %stop iteration temperature
    for n = 1:iter
        enegy1 = Fun(value);
        temp_value = Disturb(dim,lb,ub);
        enegy2 = Fun(temp_value);
        
        delta_e = enegy2 - enegy1;

        if delta_e < 0
            value = temp_value;
        else
         P=exp(-delta_e/temperature);
        if rand() <=P
                value = temp_value;
            end
        end
Positions(n,:)=value;

    end
    count = count + 1;
    enegy(count) =Fun(value);
    temperature=temperature*Tm(2);

end
fit=zeros(N,1);
for i=1:N
     fit(i,1)=Fun(Positions(i,:));
end
[~, index]=min(fit);
wbest = Positions; % Best position initialization
%gbest = Positions(index,:); % initial global position
fitness=fit;
gbest = value;
fmin0= enegy(end);
end


function Positions=initialization(SearchAgents_no,dim,ub,lb)

Boundary_no= size(ub,2); % numnber of boundaries

% If the boundaries of all variables are equal and user enter a signle
% number for both ub and lb
if Boundary_no==1
    Positions=rand(SearchAgents_no,dim).*(ub-lb)+lb;
end

% If each variable has a different lb and ub
if Boundary_no>1
    for i=1:dim
        ub_i=ub(i);
        lb_i=lb(i);
        Positions(:,i)=rand(SearchAgents_no,1).*(ub_i-lb_i)+lb_i;
    end
end
end

function [value] = Disturb(dim,lb,ub)
Boundary_no= size(ub,2); % numnber of boundaries
% If the boundaries of all variables are equal and user enter a signle
% number for both ub and lb
if Boundary_no==1
    value=rand(1,dim).*(ub-lb)+lb;
end
% If each variable has a different lb and ub
if Boundary_no>1
    for i=1:dim
        ub_i=ub(i);
        lb_i=lb(i);
        value(:,i)=rand(1,1).*(ub_i-lb_i)+lb_i;
    end
end
    
end

  
